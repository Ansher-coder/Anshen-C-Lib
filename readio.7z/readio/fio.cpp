#include <stdio.h>
#include <Windows.h>

#include <Windows.h>
#include <iostream>
#include <sys/stat.h>

#define INPUT_FILENAME "D:/Program Files/Vscode Files/readio/txt.txt"
// int GetInputFileSize(const char* filepath);
// int main()
// {
//     HANDLE c_dumpFileDescriptor;
//     HANDLE c_fileMappingObject;
//     //Get file length
//     int filelength = 0;
//     if ((filelength = (int)GetInputFileSize("D:/Program Files/Vscode Files/readio/txt.txt")) == 0)
//         return false;
//     char err_str[256] = { 0x00 };

//     c_dumpFileDescriptor = CreateFile(
//         INPUT_FILENAME,
//         GENERIC_READ | GENERIC_WRITE,
//         FILE_SHARE_READ | FILE_SHARE_WRITE,
//         NULL,
//         OPEN_EXISTING,
//         FILE_ATTRIBUTE_NORMAL,
//         NULL);
//     if (c_dumpFileDescriptor == NULL) {
//         std::cout << GetLastError() << std::endl;
//     }
//     c_fileMappingObject = CreateFileMapping(c_dumpFileDescriptor, NULL, PAGE_READWRITE, 0, 0, NULL);
//     if (c_fileMappingObject == NULL) {
//         std::cout << GetLastError() << std::endl;
//     }
//     void* mappedFileAddress = MapViewOfFile(c_fileMappingObject, FILE_MAP_ALL_ACCESS, 0, 0, filelength);
//     if (!mappedFileAddress) {
//         std::cout << GetLastError() << std::endl;
//         return false;
//     }

//     //读取内存映射中的文件内容
//     char* mem = (char*)mappedFileAddress;
//     char  c_array[64] = { 0x00 };
//     memcpy_s(c_array, sizeof(c_array), mem, filelength);
//     std::cout << "read memory:" << c_array << std::endl;

//     //修改内存映射中的内容，最后同步到文件
//     *mem = '1';

//     CloseHandle(c_fileMappingObject);
//     CloseHandle(c_dumpFileDescriptor);

// }
// //获取文件大小
// int GetInputFileSize(const char* filepath)
// {
//     if (!strlen(filepath))
//         return false;
//     struct _stat64 statbuff;
//     _stat64(filepath, &statbuff);
//     return statbuff.st_size;
// }

namespace an {

    class mmap {
        char *c_array = nullptr;
        char *c_mem = nullptr;
        const char *filename;
        size_t filelength = 0;
        size_t fpos = 0;
        size_t fgetsize(const char *filepath) {
            if (!strlen(filepath)) return false;
            struct _stat64 statbuff;
            _stat64(filepath, &statbuff);
            return statbuff.st_size;
        }
        public:
        mmap(const char *newfilename): filename(newfilename) {
            HANDLE c_dumpFileDescriptor;
            HANDLE c_fileMappingObject;
            if ((filelength = (int)fgetsize(filename)) == 0) return;
            c_dumpFileDescriptor = CreateFile(
                filename,
                GENERIC_READ | GENERIC_WRITE,
                FILE_SHARE_READ | FILE_SHARE_WRITE,
                NULL,
                OPEN_EXISTING,
                FILE_ATTRIBUTE_NORMAL,
                NULL);
            if (c_dumpFileDescriptor == NULL) throw "file not found\n";
            c_fileMappingObject = CreateFileMapping(c_dumpFileDescriptor, NULL, PAGE_READWRITE, 0, 0, NULL);
            if (c_fileMappingObject == NULL) throw "mapping failed\n";
            void *mappedFileAddress = MapViewOfFile(c_fileMappingObject, FILE_MAP_ALL_ACCESS, 0, 0, filelength);
            if (!mappedFileAddress) throw "memory mapping failed\n";
            c_mem = (char *)mappedFileAddress;
            c_array = new char[filelength + 1];
            memmove(c_array, c_mem, filelength);
            CloseHandle(c_fileMappingObject);
            CloseHandle(c_dumpFileDescriptor);
        }
        ~mmap() { if (c_array) delete[] c_array, c_array = nullptr; }
        operator char*() { return c_array; }
        char& operator[](size_t index) {
            if (index >= filelength) throw "index error in mmap\n";
            return c_array[index];
        }
    };

}

an::mmap fs("txt.txt");

int main() {
}