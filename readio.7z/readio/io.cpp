#include <unistd.h>
#include <ctype.h>
#include <string.h>
#include <stdio.h>
#include <type_traits>
using namespace std;

namespace mystd {
    char ibuf[131073];
    char obuf[131073];
    unsigned int ip = 0;
    unsigned int op = 0;
    inline char load() {
        if (ibuf[ip] == '\0') {
            ibuf[read(0, ibuf, 131072)] = '\0';
            ip = 0;
        }
        return ibuf[ip++];
    }
    template <class T>
    typename enable_if<is_integral<T>::value, void>::type in(T &x) {
        x = 0;
        int f = 1;
        char c;
        while (!isdigit(c)) {
            if (c == '-') f = -1;
            c = load();
        }
        while (isdigit(c)) {
            x = x * 10 + (c ^ '0');
            c = load();
        }
        x *= f;
    }
    void in(char& c) { c = load(); }
    inline void flush() { write(1, obuf, op), op = 0; }
    inline void send(char x) {
        obuf[op++] = x;
        if (op >= 131072) {
            flush(); 
        }
    }
    char dbuf[40001];
    constexpr int get_integer_size(unsigned long long n) {
        if (n >= 10000000000000000000u)
            return 20;
        if (n >= 1000000000000000000)
            return 19;
        if (n >= 100000000000000000)
            return 18;
        if (n >= 10000000000000000)
            return 17;
        if (n >= 1000000000000000)
            return 16;
        if (n >= 100000000000000)
            return 15;
        if (n >= 10000000000000)
            return 14;
        if (n >= 1000000000000)
            return 13;
        if (n >= 100000000000)
            return 12;
        if (n >= 10000000000)
            return 11;
        if (n >= 1000000000)
            return 10;
        if (n >= 100000000)
            return 9;
        if (n >= 10000000)
            return 8;
        if (n >= 1000000)
            return 7;
        if (n >= 100000)
            return 6;
        if (n >= 10000)
            return 5;
        if (n >= 1000)
            return 4;
        if (n >= 100)
            return 3;
        if (n >= 10)
            return 2;
        return 1;
    }
    constexpr void pre_calc() {
        int j = 0, k = 0;
        for (int i = 0; i < 10000; ++i) {
            j = 4, k = i;
            while (j--) {
                dbuf[i * 4 + j] = k % 10 | 48;
                k /= 10;
            }
        }
    }
    struct ini {
        ini() { pre_calc(); }
    } ain;

    struct finin {
        template <class Head, class... Others> finin& operator()(Head &head, Others &...others) {
            in(head); // 处理头部参数
            if constexpr (sizeof...(others) > 0) { // 如果还有其他参数
                this->operator()(others...); // 递归调用
            }
            return *this;
        }
    } is;

    template <class T>
    typename enable_if<is_integral<T>::value, void>::type out(T x) {
        if (op >= 131072) flush();
        if (x < 0) send('-'), x = -x;
        int digit = get_integer_size(x), len = digit;
        while (len >= 4) {
            len -= 4;
            memmove(obuf + op + len, dbuf + ((x % 10000) << 2), 4);
            x /= 10000;
        }
        memmove(obuf + op, dbuf + (x << 2) + (4 - len), len);
        op += digit;
    }

    void out(char x) { send(x); }
    struct foutout {
        template <class Head, class... Others> foutout& operator()(Head head, Others ...others) {
            out(head);
            if constexpr (sizeof...(others) > 0) { // 如果还有其他参数
                this->operator()(others...); // 递归调用
            }
            return *this;
        }
    } os;

    struct autoflush {
        ~autoflush() { flush(); }
    } d;
    
}
using mystd::is;
using mystd::os;